package com.example.minesweeper2;

public interface OnCellClickListener {
    void onCellClick(Cell cell);
}
