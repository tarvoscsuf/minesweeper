package com.example.minesweeper2;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.graphics.drawable.GradientDrawable;
import android.os.CountDownTimer;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements OnCellClickListener{
    RecyclerView gridRecyclerView;
    MineGridRecyclerAdapter mineGridRecyclerAdapter;
    MineSweeperGame game;
    TextView collision, timer, flag, flagsLeft;
    CountDownTimer countDownTimer;
    int secsElapsed;
    boolean timeStarted;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        flag = findViewById(R.id.activity_main_flag);
        flagsLeft = findViewById(R.id.activity_main_flagsleft);
        flagsLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                game.toggleMode();
                if(game.isFlagMode()){
                    GradientDrawable border = new GradientDrawable();
                    border.setColor(0xFF000000);
                    border.setStroke(1,0xFF000000);
                    flag.setBackground(border);
                }else {
                    GradientDrawable border = new GradientDrawable();
                    border.setColor(0xFF000000);
                    flag.setBackground(border);
                }
            }
        });
        collision = findViewById(R.id.activity_main_collision);
        collision.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                game = new MineSweeperGame(10, 10);
                mineGridRecyclerAdapter.setCells(game.getMineGrid().getCells());
                timeStarted = false;
                countDownTimer.cancel();
                secsElapsed = 0;
                timer.setText(R.string.def_count);
                flagsLeft.setText(String.format("%03d",game.getNumberofBombs() - game.getFlagcnt()));
            }
        });

        timer = findViewById(R.id.activity_main_timer);
        timeStarted = false;
        countDownTimer = new CountDownTimer(180000L,1000){
            public void onTick(long millisUntilFinished){
                secsElapsed += 1;
                timer.setText(String.format("%03d",secsElapsed));
            }
            public void onFinish(){
                game.outOfTime();
                Toast.makeText(getApplicationContext(),"Game Over: Time Expired", Toast.LENGTH_SHORT).show();
                game.getMineGrid().revealAllBombs();
                mineGridRecyclerAdapter.setCells(game.getMineGrid().getCells());
            }
        };

        gridRecyclerView = findViewById(R.id.activity_main_grid);
        gridRecyclerView.setLayoutManager(new GridLayoutManager(this, 10));
        game = new MineSweeperGame(10, 10);
        mineGridRecyclerAdapter = new MineGridRecyclerAdapter(game.getMineGrid().getCells(), this);
        gridRecyclerView.setAdapter(mineGridRecyclerAdapter);
        flagsLeft.setText(String.format("%03d",game.getNumberofBombs() - game.getFlagcnt()));
    }

    @Override
    public void onCellClick(Cell cell) {
        game.handleCellClick(cell);
        flagsLeft.setText(String.format("%03d",game.getNumberofBombs() - game.getFlagcnt()));

        if(!timeStarted){
            countDownTimer.start();
            timeStarted = true;
        }
        if (game.isGameOver()) {
            countDownTimer.cancel();
            Toast.makeText(getApplicationContext(), "Game Over", Toast.LENGTH_SHORT).show();
            game.getMineGrid().revealAllBombs();
        }
        if (game.isGameWon()) {
            countDownTimer.cancel();
            Toast.makeText(getApplicationContext(), "Game Won", Toast.LENGTH_SHORT).show();
            game.getMineGrid().revealAllBombs();
        }
        mineGridRecyclerAdapter.setCells(game.getMineGrid().getCells());
    }
}