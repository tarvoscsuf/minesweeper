package com.example.minesweeper2;

import java.util.ArrayList;
import java.util.List;

// BECAREFUL WITH ACITIVTY_MAIL_XML!!! worst case clone & revert

public class MineSweeperGame {
    private MineGrid mineGrid;
    private boolean clearMode;
    private boolean isGameOver;
    private boolean timeExpired;
    private boolean flagMode;
    private int flagcnt;
    private int numberofBombs;

    public MineSweeperGame(int size, int numberofBombs) {
        this.clearMode = true;
        this.isGameOver = false;
        this.timeExpired = false;
        this.flagMode = false;
        this.numberofBombs = numberofBombs;
        flagcnt = 0;
        mineGrid = new MineGrid(size);
        mineGrid.generateGrid(numberofBombs);
    }

    public void handleCellClick(Cell cell) {
        if (!isGameOver && !isGameWon() && !timeExpired && !cell.isRevealed()) {
            if (clearMode){
                clear(cell);
            }else if(flagMode) {
                flag(cell);
            }
        }
    }
    public void clear(Cell cell) {
        int index = getMineGrid().getCells().indexOf(cell);
        getMineGrid().getCells().get(index).setRevealed(true);

        if (cell.getValue() == Cell.BLANK) {
            List<Cell> toClear = new ArrayList<>();
            List<Cell> toCheckAdjacents = new ArrayList<>();

            toCheckAdjacents.add(cell);
            while (toCheckAdjacents.size() > 0) {
                Cell c = toCheckAdjacents.get(0);
                int cellIndex = getMineGrid().getCells().indexOf(c);
                int[] cellPos = getMineGrid().toXY(cellIndex);
                for (Cell adjacent : getMineGrid().adjacentCells(cellPos[0], cellPos[1])) {
                    if (adjacent.getValue() == Cell.BLANK) {
                        if (!toClear.contains(adjacent)) {
                            if (!toCheckAdjacents.contains(adjacent)) {
                                toCheckAdjacents.add(adjacent);
                            }
                        }
                    } else {
                        if (!toClear.contains(adjacent)) {
                            toClear.add(adjacent);
                        }
                    }
                }
                toCheckAdjacents.remove(c);
                toClear.add(c);
            }
            for (Cell c : toClear) {
                c.setRevealed(true);
            }
        } else if (cell.getValue() == Cell.BOMB){
            isGameOver = true;
        }
    }
    public boolean isGameWon() {
        int numberUnrevealed = 0;
        for (Cell c: getMineGrid().getCells()) {
            if(c.getValue() != Cell.BOMB && c.getValue() != Cell.BLANK && !c.isRevealed()) {
                numberUnrevealed++;
            }
        }
        if (numberUnrevealed == 0) {
            return true;
        }else{
            return false;
        }
    }

    public void flag(Cell cell) {
        if(cell.isRevealed()){
            cell.setFlagged(!cell.isFlagged());
            int cnt = 0;
            for(Cell c: getMineGrid().getCells()){
                if(c.isFlagged()){
                    cnt++;
                }
            }
            flagcnt = cnt;
        }
    }

    public void toggleMode() {
        clearMode = !clearMode;
        flagMode = !flagMode;
    }

    public void outOfTime() {
        timeExpired = true;
    }
    public MineGrid getMineGrid() {
        return mineGrid;
    }

    public boolean isGameOver(){
        return isGameOver;
    }

    public boolean isFlagMode(){
        return flagMode;
    }

    public int getFlagcnt() {
        return flagcnt;
    }
    public int getNumberofBombs() {
        return numberofBombs;
    }
}

